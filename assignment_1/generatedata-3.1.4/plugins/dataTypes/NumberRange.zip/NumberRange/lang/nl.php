<?php

$L = array();
$L["DATA_TYPE_NAME"] = "Aantal Range";

$L["and"] = "en";
$L["between"] = "Tussen";
$L["help"] = "Dit genereert willekeurig een getal tussen de waarden die u opgeeft. Beide velden kunt u negatieve getallen in te voeren.";
$L["incomplete_fields"] = "Vul het nummer bereik (laagste en hoogste aantallen) voor de volgende rijen:";