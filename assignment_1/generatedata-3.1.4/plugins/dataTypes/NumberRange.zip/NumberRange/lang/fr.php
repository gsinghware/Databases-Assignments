<?php

$L = array();
$L["DATA_TYPE_NAME"] = "Plage de numéros";

$L["and"] = "et";
$L["between"] = "Entre";
$L["help"] = "Cela génère au hasard un nombre entre les valeurs que vous spécifiez. Les deux champs vous permettent d'entrer des nombres négatifs.";
$L["incomplete_fields"] = "Précisez un minimum et un maximum pour les lignes suivantes:";
