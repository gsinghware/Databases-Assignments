<?php

$L = array();
$L["DATA_TYPE_NAME"] = "Rango numérico";

$L["and"] = "y";
$L["between"] = "Entre";
$L["help"] = "Este tipo genera un número aleatorio entre los valores que especifiques. Ambos campos permite introducir números negativos.";
$L["incomplete_fields"] = "Por favor, introduce el rango numérico (números inferior y superior) para las siguientes filas:";
