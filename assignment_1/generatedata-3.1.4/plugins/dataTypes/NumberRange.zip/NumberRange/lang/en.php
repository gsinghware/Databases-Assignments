<?php

$L = array();
$L["DATA_TYPE_NAME"] = "Number Range";

$L["and"] = "and";
$L["between"] = "Between";
$L["int_or_float"] = "Please select a choice in the Example columns to either generate 'Integral' or 'Real Numbers'."; 
$L["help"] = "This randomly generates a number between the values you specify. Both fields allow you to enter negative numbers.";
$L["incomplete_fields"] = "Please enter the correct number range (lowest and highest numbers) for the following rows: ";
$L["enter_int"] = "You must enter interger values in the range.";
